public interface Ibu {
  public void NamaIbu();
  public void SifatIbu();
}
