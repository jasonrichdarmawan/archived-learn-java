public interface Kakek {
  public void NamaKakek();
  public void SifatKakek();
}
