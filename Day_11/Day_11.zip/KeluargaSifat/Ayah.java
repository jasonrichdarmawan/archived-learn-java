public interface Ayah extends Kakek {
  public void NamaAyah();
  public void SifatAyah();
}
