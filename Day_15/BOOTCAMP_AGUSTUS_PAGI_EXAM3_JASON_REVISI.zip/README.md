Pastikan ServerSocket listening di port 8080 sebelum program1 menyala.

- [x] program2: ServerSocket listening di port 8080
- [x] program1: send data through socket.