package com.example.designpattern;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DesignpatternApplicationTests {

	@Test
	void contextLoads() {
	}

}
