package com.company;

import com.company.Menu.MenuUtil;

public class Main {

    public static void main(String[] args) {
        MenuUtil.showMenu();
    }
}
